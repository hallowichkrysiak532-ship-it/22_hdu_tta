#include "ARCL_OSAL.h"
#include "UdpDataPort.h"
#include "gcs_interface.h"

static UdpDataPort udp("udp", 10086, "127.0.0.1", 47140, DataPort::MODE_INCOME | DataPort::MODE_OUTCOME);
void *pth_udp;
static int udp_run = 1;
void recv_udp(void* data, int size) {
		EmbeInterfaceSend((unsigned char *)data,size);

}

void send_udp(void* data, int size) {
	BufferItem* t = new BufferItem((char*)data, size);
    udp.send(t);
}

void* func1(void*) 
{
    int count = 0;
    while(udp_run) {
        
        BufferItem* item = NULL;
        item = udp.recv();
		unsigned char queue_receive[1024];
		void *send;
		uint32_t send_len=0;

        if(item) {
            count = 1;

            char* data = item->data();
			recv_udp(data, item->size());

            delete item;
        }

		while(1)
		{
			send_len = EmbeInterfaceReceive(queue_receive,1024);
			if(send_len > 0)
			{
				send = queue_receive;
				send_udp(send,send_len);
			}
			else
				break;
		}

		

        if(count) {
            usleep(10);
        }
    }
}
void start_udp() {
	udp.start();
	ACRL_CreatPthread("udp", &pth_udp, func1,0,50,NULL);
}
void stop_udp() {
	udp_run = 0;
	ACRL_DestoryPthread(&pth_udp);
	udp.stop();
}

